
#import "CFTextAttachment.h"

@implementation CFTextAttachment

@end
