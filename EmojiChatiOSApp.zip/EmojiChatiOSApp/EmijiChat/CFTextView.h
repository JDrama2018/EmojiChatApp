
#import <UIKit/UIKit.h>

@interface CFTextView : UITextView

@end
