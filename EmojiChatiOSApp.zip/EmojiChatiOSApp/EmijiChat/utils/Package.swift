//
//  Package.swift
//  EmijiChat
//
//  Created by LEE on 6/17/17.
//  Copyright © 2017 Meapp90. All rights reserved.
//

import Foundation
import PackageDescription

let package = Package(
    name: "EmijiChat",      //"YOUR_PROJECT_NAME",
    targets: [],
    dependencies: [
        .Package(url: "git@github.com:4taras4/CountryCode.git")
    ]
)

no such module 'PackageDescrition'
