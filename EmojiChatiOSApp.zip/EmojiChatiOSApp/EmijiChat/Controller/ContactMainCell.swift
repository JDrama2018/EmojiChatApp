//
//  ContactMainCell.swift
//  EmijiChat
//
//  Created by LEE on 6/22/17.
//  Copyright © 2017 Meapp90. All rights reserved.
//

import Foundation
import UIKit



class ContactMainCell: UITableViewCell {    

    @IBOutlet weak var avatar_Image: UIImageView!
    
    @IBOutlet weak var fullname_Label: UILabel!
    @IBOutlet weak var time_Label: UILabel!
    
}
