import XCTest
@testable import EmijiChatTests

XCTMain([
     testCase(EmijiChatTests.allTests),
])
