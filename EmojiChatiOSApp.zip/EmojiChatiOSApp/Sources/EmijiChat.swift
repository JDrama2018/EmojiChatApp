struct EmijiChat {

    var text = "Hello, World!"
}
